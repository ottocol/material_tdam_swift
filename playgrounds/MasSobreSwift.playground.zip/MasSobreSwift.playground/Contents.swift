//: [⬅️](@previous) [➡️](@next)
//: Una clausura es un bloque de **código** que puede ser tratado como un **objeto**. Es algo así como una *función anónima* con una sintaxis simplificada


var primeroMenor = {(a:Int, b:Int) -> Bool in return a<b  }
primeroMenor(1,2)
