//:[⬅️](@previous) [➡️](@next)
//: Una clausura es un bloque de **código** que puede ser tratado como un **objeto**. Es algo así como una *función anónima* con una sintaxis simplificada


//Esto no tiene sentido por sí solo, pero ahora veremos
//{(a:Int, b:Int) -> Bool in return a<b  }

//:  
