//:[⬅️](@previous) [➡️](@next)
//: # Superclase y protocolos
//: En la declaración de una clase, la superclase debe venir antes de los protocolos que implemente
//:```swift
//: class MiClase: Superclase, ProtocoloUno, ProtocoloDos {
//:    //Definición de la clase
//: }
//:```
//: