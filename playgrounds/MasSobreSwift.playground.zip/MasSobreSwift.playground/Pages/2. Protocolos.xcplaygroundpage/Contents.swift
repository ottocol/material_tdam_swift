//: # 2. Protocolos y delegación
//:[⬅️](@previous) [➡️](@next)
