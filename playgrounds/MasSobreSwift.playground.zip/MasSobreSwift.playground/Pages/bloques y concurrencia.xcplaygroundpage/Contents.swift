//:[⬅️](@previous) [➡️](@next)
//: ## Bloques y concurrencia
//: Los bloques nos dan la posibilidad de usar una **sintaxis concisa y relativamente “limpia”** para especificar código que se debe ejecutar de manera concurrente.

//:
