//:[⬅️](@previous) [➡️](@next)
//: ## Incluir expresiones en una cadena
let manzanas = 3
let naranjas = 5
let resumenManzanas = "Tengo \(manzanas) manzanas."
let resumenFrutas = "Tengo \(manzanas + naranjas) frutas."
//:
