//:[⬅️](@previous) [➡️](@next)
//: ## Conversión de tipos
//: Debe ser explícita, no se hace implícitamente
var mensaje = " botellas de ron"
var num = 55
print(String(num)+mensaje)
//:
