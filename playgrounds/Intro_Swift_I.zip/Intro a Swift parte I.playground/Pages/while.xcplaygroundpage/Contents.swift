//:[⬅️](@previous) [➡️](@next)
//: ## `while` y `repeat..while`
var n = 2
while n < 2 {
    n = n * 2
}
print(n)

var m = 2
repeat {
    m = m * 2
} while m < 2
print(m)
//:
