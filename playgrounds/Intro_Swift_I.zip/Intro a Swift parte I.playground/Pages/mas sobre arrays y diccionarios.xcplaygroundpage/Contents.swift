//:[⬅️](@previous) [➡️](@next)
//: ## Más sobre arrays y diccionarios
//Inicialización vacía
var listaCompra = [String]()
var trabajos = [String:String]()

//vaciar un array ya existente
listaCompra.append("patatas")
listaCompra = []
//sigue siendo de tipo [String]
listaCompra.append("pan")
//:
