//:[⬅️](@previous) [➡️](@next)
//: ## Tipos e inferencia de tipos
//: Si asignamos un valor inicial a una variable o cte. no es necesario declarar el tipo, Swift lo puede **inferir**
let implicitInteger = 70
var implicitDouble = 70.0
let explicitDouble: Double = 70
//: 
